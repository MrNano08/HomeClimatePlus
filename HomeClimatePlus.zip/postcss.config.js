export default {
    plugins: {
      '@tailwindcss/postcss': {},   // << obligatorio en v4
      autoprefixer: {},
    },
  };